#include <iostream>

#include "Rational.h"

int main(int, char**)
{
    Rational a{45, 8};
    Rational b{3, 4};

    auto r = a + b;

    r /= b;

    if (r > a/b)
    {
        std::cout << r << " is bigger than " << (a/b);
    }
}
